package com.example.OneToOne1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OneToOne1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
