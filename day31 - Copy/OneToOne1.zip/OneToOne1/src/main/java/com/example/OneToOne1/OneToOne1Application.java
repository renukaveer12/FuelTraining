package com.example.OneToOne1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OneToOne1Application {

	public static void main(String[] args) {
		SpringApplication.run(OneToOne1Application.class, args);
	}

}
