package com.example.OneToManydemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OneToManydemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
